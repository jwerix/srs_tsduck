---
name: Question
about: Ask a question regarding SRT
title: ''
labels: 'Type: Question'
assignees: ''

---

When asking a question please also include where you looked for an answer (so we can update the documentation if needed).

You are encouraged to ask general questions regarding SRT in the [SRT Alliance Slack channel](https://slackin-srtalliance.azurewebsites.net/).
