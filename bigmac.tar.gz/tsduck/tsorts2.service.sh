#!/bin/bash

/usr/local/bin/tsorts  /live2_videofifo.ts /null.ts > /live2_videofifo2.ts
