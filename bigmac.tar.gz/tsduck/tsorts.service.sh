#!/bin/bash

/usr/local/bin/tsorts  /live_videofifo.ts /null.ts > /live_videofifo2.ts
