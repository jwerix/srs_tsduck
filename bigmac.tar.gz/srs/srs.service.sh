#!/bin/bash
cd /tmp/srs/trunk
./objs/srs -c ./conf/main.conf
